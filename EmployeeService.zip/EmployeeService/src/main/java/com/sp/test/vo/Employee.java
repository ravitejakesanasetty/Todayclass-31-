package com.sp.test.vo;

public class Employee {
	
    private String id;
	
    private String name;
	
    private String add;
	public String getId() {
		return id;
	}
	public Employee() {
		super();
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
    
    
}
